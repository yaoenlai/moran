<?php
// +----------------------------------------------------------------------
// | CoreThink [ Simple Efficient Excellent ]
// +----------------------------------------------------------------------
// | Copyright (c) 2014 http://www.corethink.cn All rights reserved.
// +----------------------------------------------------------------------
// | Author: zxq <http://www.corethink.cn>
// +----------------------------------------------------------------------
//主题信息配置
return array(
    //主题信息
    'info' => array(
        'name'        => 'Love',
        'title'       => '交友',
        'description' => '交友介绍页',
        'developer'   => '北京优异科技有限公司',
        'website'     => 'http://www.uera.cn',
        'version'     => '1.1',
    ),

    //主题配置
    'config' => array(),
);
