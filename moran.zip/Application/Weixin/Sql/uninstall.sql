DROP TABLE IF EXISTS `oc_weixin_custom_menu`;
DROP TABLE IF EXISTS `oc_weixin_custom_reply`;
DROP TABLE IF EXISTS `oc_weixin_material`;
DROP TABLE IF EXISTS `oc_weixin_user_bind`;
