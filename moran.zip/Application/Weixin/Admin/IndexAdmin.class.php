<?php
// +----------------------------------------------------------------------
// | wiera [ Simple Efficient Excellent ]
// +----------------------------------------------------------------------
// | Copyright (c) 2014 http://www.uera.cn All rights reserved.
// +----------------------------------------------------------------------
// | Author: zxq
// +----------------------------------------------------------------------
namespace Weixin\Admin;
use Admin\Controller\AdminController;
/**
 * 默认控制器
 * @author zxq
 */
class IndexAdmin extends AdminController {
    /**
     * 默认方法
     * @author zxq
     */
    public function index() {
        $this->assign('meta_title', '微信模块');
        $this->display();
    }
}