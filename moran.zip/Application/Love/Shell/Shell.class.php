<?php
// +----------------------------------------------------------------------
// | wiera [ Simple Efficient Excellent ]
// +----------------------------------------------------------------------
// | Copyright (c) 2014 http://www.uera.cn All rights reserved.
// +----------------------------------------------------------------------
// | Author: zxq
// +----------------------------------------------------------------------
namespace Love\Shell;
use Home\Controller\ApiController;
/**
 * 聚合平台接口父控制器
 * @author zxq
 */
class Shell extends ApiController {
	
	//默认加载的公共信息
	protected function _initialize(){
		parent::_initialize();
	}
	
}