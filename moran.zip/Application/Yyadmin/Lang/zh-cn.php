<?php
return array(
    'index'     =>  '列表',
    'add'       =>  '新增',
    'del'       =>  '删除',
    'edit'      =>  '编辑',
    
    'NAV'       =>  '导航',
    'COLUMN'    =>  '栏目',
    'ARTICLE'   =>  '文章',
    'MEMBER'    =>  '会员',
);