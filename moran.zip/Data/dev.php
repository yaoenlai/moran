<?php
// +----------------------------------------------------------------------
// | wiera [ Simple Efficient Excellent ]
// +----------------------------------------------------------------------
// | Copyright (c) 2014 http://www.uera.cn All rights reserved.
// +----------------------------------------------------------------------
// | Author: zxq
// +---------------------------------------------------------------------- 

/**
 * 开发模式数据库配置文件
 */
//$_SERVER[ENV_PRE.'DEV_MODE']  = 'true';
//$_SERVER[ENV_PRE.'DB_TYPE']   = 'mysql';
//$_SERVER[ENV_PRE.'DB_HOST']   = '127.0.0.1';
//$_SERVER[ENV_PRE.'DB_NAME']   = 'opencmf';
//$_SERVER[ENV_PRE.'DB_USER']   = 'root';
//$_SERVER[ENV_PRE.'DB_PWD']    = '';
//$_SERVER[ENV_PRE.'DB_PORT']   = '3306';
//$_SERVER[ENV_PRE.'DB_PREFIX'] = 'oc_';
//$_SERVER[ENV_PRE.'APP_DEBUG'] = 'false';
